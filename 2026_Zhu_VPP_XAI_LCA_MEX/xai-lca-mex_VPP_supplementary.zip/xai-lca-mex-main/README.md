xai-lca-mex

Code and data accompanying an XAI–LCA framework for material-extrusion additive manufacturing (MEX/FDM), developed and evaluated primarily on PLA.

This repository supports:

Model building (Random Forest surrogates, including EC/MC decomposition),

Figure generation (scripts + static data tables used in the manuscript),

Application example (3DBenchy: PrusaSlicer → G-code → automatic LCA Excel report).

Repository structure

01_model_building/
Trained models (*.pkl) and datasets (*.xlsx) for:

Direct-RFM (baseline)

EC-RFM (electricity-driven contribution)

MC-RFM (material-driven contribution)

EC/MC-RFM totals (EC + MC)

02_figure_generation/
Data tables and Python scripts to reproduce Figures 6–12.

03_benchy_application/
End-to-end application demonstration for 3DBenchy, including:

four sliced scenarios (PLA/PETG × infill 100/70),

auto-generated LCA Excel reports,

factor tables (electricity per minute; material per kg),

post_lca_report.py for PrusaSlicer post-processing automation.

geometries/
STL files used in the work (rectangular specimen and 3DBenchy reference).

Quick start
1) Install (minimal)
pip install openpyxl pandas scikit-learn joblib

2) Run the Benchy post-processing script (example)
python 03_benchy_application/post_lca_report.py 03_benchy_application/PLA_100.gcode


This generates an Excel file named:
PLA_100_lca.xlsx (same folder as the G-code).

3) Reproduce manuscript figures

See 02_figure_generation/README.md for per-figure scripts and required input tables.

Scope note

The Benchy example and factor tables in 03_benchy_application/ are intended for a controlled printing-stage comparison (electricity and filament consumption during printing). Direct on-site emissions are not included in this simplified accounting.

Citation

If you use this repository, please cite the associated manuscript:

Explainable AI Analysis of Printing Parameter Effects on Life Cycle Assessment for Sustainable Material-Extrusion Additive Manufacturing  
Yanlong Zhu et al., *Virtual and Physical Prototyping*, 2026.  
DOI: 10.1080/17452759.2026.2632456

Yanlong Zhu (TU Berlin)
Email: [yanlong.zhu@campus.tu-berlin.de
]
