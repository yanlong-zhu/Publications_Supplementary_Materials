# XAI–LCA Random Forest Models for Material Extrusion (PLA)

This folder provides the code, trained models, and datasets used for the
**random forest modelling part** of the XAI–LCA framework in our study on
material extrusion (MEX) of PLA.

> _[Towards Sustainable Material-Extrusion Additive Manufacturing: Explainable AI Analysis of Printing Parameter Effects on Life Cycle Assessment]_  
> Yanlong Zhu et al., [Journal, Year].

The goal is to make this part of the workflow **reproducible and reusable**.
Users can plug in their own printing parameters and obtain predictions for
four life cycle assessment (LCA) indicators using the trained random forest
models.

---

## 1. Problem setting

We consider PLA material extrusion (MEX/FDM) printing. Each print is
described by four process parameters:

- `print_speed`  
- `layer_height`  
- `infill_density`  
- `raster_angle`  

The models predict four ReCiPe 2016 Midpoint (H) indicators:

- `GWP` – Global warming  
- `FRS` – Fossil resource scarcity  
- `OFHH` – Ozone formation, human health  
- `TA` – Terrestrial acidification  

We train and compare three random forest strategies:

1. **Direct-RFM**  
   Direct mapping from process parameters to the four *total* LCA indicators.

2. **EC-RFM**  
   Random forest model for the contribution from **energy consumption (EC)**.

3. **MC-RFM**  
   Random forest model for the contribution from **material consumption (MC)**.

The **EC/MC-RFM** decomposition model used in the paper is obtained by
**additively combining** the EC-RFM and MC-RFM predictions for each indicator.

---

## 2. Folder structure (01_model_building)

The files in this folder are:

```text
01_model_building/
├─ Direct-RFM.xlsx              # 134-sample training data for Direct-RFM
├─ Direct-RFM.pkl               # Trained Direct-RFM (multi-output RF model)
├─ EC-RFM.xlsx                  # 134-sample training data for EC-RFM
├─ EC-RFM.pkl                   # Trained EC-RFM (EC contribution)
├─ MC-RFM.xlsx                  # 134-sample training data for MC-RFM
├─ MC-RFM.pkl                   # Trained MC-RFM (MC contribution)
├─ predictions_434_samples.xlsx # 434-sample dataset used in the paper
├─ input_params_template.xlsx   # Template for user-defined input parameters
├─ ecmc_model.py                # Python wrapper for EC/MC-RFM (ECMC model)
├─ predict_lca.py               # Command-line script to run predictions
└─ README.md                    # This file
```
Note: File names can be changed if needed, but the examples below assume
the names shown above.


---

## 3. Data formats

### 3.1 Input parameters (for prediction)

All input files used for prediction must contain at least the following
columns (case-sensitive):

print_speed

layer_height

infill_density

raster_angle

The file input_params_template.xlsx provides an example with exactly these
four columns. Users can fill this file with their own parameter combinations
and run predictions with the trained models.

### 3.2 Training data (134 samples)

The three training files

Direct-RFM.xlsx

EC-RFM.xlsx

MC-RFM.xlsx

each contain 134 semi-real samples generated from slicing and LCA.

Columns typically include:

the four process parameters
(print_speed, layer_height, infill_density, raster_angle), and

the corresponding LCA indicators used to train the respective model
(GWP, FRS, OFHH, TA, either as totals or EC/MC contributions).

These training sets allow users to retrain or further analyse the models
if desired.

### 3.3 434-sample dataset

predictions_434_samples.xlsx contains the 434 parameter combinations
used in the paper:

134 baseline samples + 300 virtual LHS samples, and

the corresponding model predictions for the four indicators.

This dataset is provided to enable full reproducibility of the figures and
analysis in the paper.


---

## 4. Requirements

Python ≥ 3.10

Recommended packages:

pandas

scikit-learn

joblib

openpyxl (for reading/writing .xlsx files)

Install via:

pip install pandas scikit-learn joblib openpyxl

---

## 5. EC/MC decomposition model (EC/MC-RFM)

### 5.1 Command-line usage

The script predict_lca.py provides a simple command-line interface to run
the EC/MC decomposition model.

Basic usage (with default file names):

python predict_lca.py


This will:

read input_params_template.xlsx (or another file if you set --input),

use EC-RFM.pkl and MC-RFM.pkl to predict the four indicators,

write the results to predictions_ecmc.xlsx.

Custom input/output files:

python predict_lca.py \

  --input my_params.xlsx \
  
  --output my_predictions.xlsx

The input Excel file must contain the four parameter columns described in
Section 3.1.

### 5.2 Python API usage

You can also use the EC/MC model directly from Python.

import pandas as pd
from ecmc_model import ECMCRandomForest

#### 1. Prepare a DataFrame with the four required columns
df_params = pd.DataFrame([
    {"print_speed": 60, "layer_height": 0.20, "infill_density": 20, "raster_angle": 45},
    {"print_speed": 80, "layer_height": 0.30, "infill_density": 50, "raster_angle": 0},
])

#### 2. Load the EC/MC models (paths can be adjusted)
model = ECMCRandomForest(
    ec_model_path="EC-RFM.pkl",
    mc_model_path="MC-RFM.pkl",
)

#### 3. Predict EC, MC, and total impacts
df_out = model.predict(df_params)
print(df_out.head())


The output DataFrame contains the original parameters plus 12 columns:

GWP_EC, FRS_EC, OFHH_EC, TA_EC

GWP_MC, FRS_MC, OFHH_MC, TA_MC

GWP_TOT, FRS_TOT, OFHH_TOT, TA_TOT

where *_TOT = *_EC + *_MC for each indicator.


---

## 6. Direct-RFM baseline model

The file Direct-RFM.pkl stores the trained Direct-RFM (baseline) model,
which directly maps

(print_speed, layer_height, infill_density, raster_angle)
    → (GWP, FRS, OFHH, TA)


Example usage:

import joblib
import pandas as pd
from ecmc_model import PARAM_COLS  # or define the same list here

direct_model = joblib.load("Direct-RFM.pkl")

df_params = pd.read_excel("input_params_template.xlsx")
X = df_params[PARAM_COLS]
y_pred = direct_model.predict(X)

df_direct = df_params.copy()
df_direct[["GWP", "FRS", "OFHH", "TA"]] = y_pred
print(df_direct.head())


This allows users to compare the decomposition-based EC/MC-RFM predictions
with the direct baseline model.


---

## 7. Citation

If you use this code, models, or datasets in your research, please cite:

[Towards Sustainable Material-Extrusion Additive Manufacturing: Explainable AI Analysis of Printing Parameter Effects on Life Cycle Assessment]

Yanlong Zhu et al., [Journal, Year].

DOI: [to be added]

You may also include a link to this repository in your acknowledgements or
supplementary materials.


---

## 8. Contact

For questions, issues, or suggestions, please contact:

Yanlong Zhu  

Technische Universität Berlin (TU Berlin)  

Email: [yanlong.zhu@campus.tu-berlin.de]  

or open an issue on this GitHub repository.

