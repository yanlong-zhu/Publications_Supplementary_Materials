# predict_lca.py
import argparse
from pathlib import Path

import pandas as pd

from ecmc_model import ECMCRandomForest, PARAM_COLS


# ---- Excel column aliasing (template -> model) ----
PARAM_ALIASES = {
    "print_speed": ["print_speed", "Print_Speed", "Print speed", "printing_speed", "PrintSpeed", "speed", "Speed"],
    "layer_height": ["layer_height", "Layer_Height", "Layer height", "LH", "layerheight"],
    "infill_density": ["infill_density", "Infill_Density", "Infill density", "infill", "Infill"],
    "raster_angle": ["raster_angle", "Raster_Angle", "raster angle", "RA", "angle", "RasterAngle"],
}

# model indicator -> template indicator
TOT_TO_TEMPLATE = {
    "GWP_TOT": "Global warming",
    "FRS_TOT": "Fossil resource scarcity",
    "OFHH_TOT": "Ozone formation, Human health",
    "TA_TOT": "Terrestrial acidification",
}


def _find_col(df: pd.DataFrame, candidates: list[str]) -> str | None:
    cols = list(df.columns)
    for c in candidates:
        if c in cols:
            return c
    return None


def normalize_input_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Rename parameter columns from template-style names to the model-required PARAM_COLS.
    Does NOT modify indicator columns.
    """
    rename_map = {}
    for target, candidates in PARAM_ALIASES.items():
        found = _find_col(df, candidates)
        if found is None:
            raise ValueError(
                f"Cannot find a column for '{target}'. Tried aliases: {candidates}. "
                f"Available columns: {list(df.columns)}"
            )
        rename_map[found] = target

    return df.rename(columns=rename_map)


def main():
    parser = argparse.ArgumentParser(
        description="Predict LCA indicators using EC/MC-RFM models and write totals back to the template columns."
    )
    parser.add_argument(
        "--input",
        type=str,
        default="input_params_template.xlsx",
        help="Excel file with printing parameters (must include the 4 params; aliases supported).",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="predictions_ecmc.xlsx",
        help="Output Excel file path.",
    )
    parser.add_argument(
        "--sheet",
        type=str,
        default="Sheet1",
        help="Sheet name (default: Sheet1). Use 0 for first sheet.",
    )
    parser.add_argument(
        "--keep_components",
        action="store_true",
        help="If set, also keep *_EC and *_MC columns in the output file.",
    )

    # === KEY: runtime scaling because PKL models are on the old (27) scale ===
    parser.add_argument(
        "--scale_factor",
        type=float,
        default=80.0 / 27.0,
        help=(
            "Global scaling applied to predicted columns (*_EC, *_MC, *_TOT). "
            "Default is 80/27 (~2.962963) to convert old-scale model outputs to 80W scale. "
            "Set to 1.0 if your PKL models are already on the 80W scale."
        ),
    )

    args = parser.parse_args()

    input_path = Path(args.input).expanduser().resolve()
    output_path = Path(args.output).expanduser().resolve()

    print(f"Reading input from: {input_path}")
    sheet = 0 if str(args.sheet).strip() == "0" else args.sheet
    df_raw = pd.read_excel(input_path, sheet_name=sheet)

    # Normalize parameter column names to match PARAM_COLS
    df = normalize_input_columns(df_raw)

    # Ensure required columns exist (after renaming)
    missing = [c for c in PARAM_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"Still missing required columns: {missing}. Found: {list(df.columns)}")

    # Load models
    model = ECMCRandomForest(
        ec_model_path="EC-RFM.pkl",
        mc_model_path="MC-RFM.pkl",
    )

    result_full = model.predict(df)

    # Apply scaling to ALL predicted columns to keep consistency (TOT = EC + MC)
    kappa = float(args.scale_factor)
    pred_cols = [c for c in result_full.columns if c.endswith(("_EC", "_MC", "_TOT"))]
    if kappa != 1.0:
        result_full[pred_cols] = result_full[pred_cols].apply(pd.to_numeric, errors="coerce") * kappa
        print(f"Applied scale_factor = {kappa:.6f} to {len(pred_cols)} predicted columns.")
    else:
        print("scale_factor = 1.0 (no rescaling applied).")

    # Write totals back to template indicator columns (after scaling)
    for src, dst in TOT_TO_TEMPLATE.items():
        if src not in result_full.columns:
            raise ValueError(f"Missing expected model output column: {src}")
        df_raw[dst] = result_full[src].values

    # Optionally keep EC/MC/TOT columns as well (after scaling)
    if args.keep_components:
        for k in ["GWP", "FRS", "OFHH", "TA"]:
            df_raw[f"{k}_EC"] = result_full[f"{k}_EC"].values
            df_raw[f"{k}_MC"] = result_full[f"{k}_MC"].values
            df_raw[f"{k}_TOT"] = result_full[f"{k}_TOT"].values

    print(f"Saving predictions to: {output_path}")
    df_raw.to_excel(output_path, index=False)
    print("Done.")


if __name__ == "__main__":
    main()
