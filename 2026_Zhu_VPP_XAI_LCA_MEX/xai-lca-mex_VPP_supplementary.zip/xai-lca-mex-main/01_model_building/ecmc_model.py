# ecmc_model.py
import pandas as pd
import joblib
from pathlib import Path

PARAM_COLS = ["print_speed", "layer_height", "infill_density", "raster_angle"]
INDICATORS = ["GWP", "FRS", "OFHH", "TA"]


class ECMCRandomForest:
    """
    Wrapper for EC-RFM + MC-RFM models.

    Loads two scikit-learn multi-output regressors:
    - EC-RFM.pkl: electricity-driven impacts (4 outputs: GWP, FRS, OFHH, TA)
    - MC-RFM.pkl: material-driven impacts (4 outputs: GWP, FRS, OFHH, TA)
    """

    def __init__(
        self,
        ec_model_path: str = "EC-RFM.pkl",
        mc_model_path: str = "MC-RFM.pkl",
        scale_factor: float = 1.0,
    ):
        base = Path(__file__).resolve().parent
        self.ec_model = joblib.load(base / ec_model_path)
        self.mc_model = joblib.load(base / mc_model_path)

        self.scale_factor = float(scale_factor)

    def _check_input(self, df: pd.DataFrame) -> pd.DataFrame:
        missing = [c for c in PARAM_COLS if c not in df.columns]
        if missing:
            raise ValueError(
                f"Input is missing columns: {missing}. "
                f"Required columns are: {PARAM_COLS}"
            )
        return df[PARAM_COLS].copy()

    def predict(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Parameters
        ----------
        df : DataFrame
            Must contain the four parameter columns defined in PARAM_COLS.

        Returns
        -------
        DataFrame with EC, MC and total impacts for each indicator.
        Columns appended:
            {GWP,FRS,OFHH,TA}_EC
            {GWP,FRS,OFHH,TA}_MC
            {GWP,FRS,OFHH,TA}_TOT
        """
        x = self._check_input(df)

        ec_pred = self.ec_model.predict(x)
        mc_pred = self.mc_model.predict(x)

        if self.scale_factor != 1.0:
            ec_pred = ec_pred * self.scale_factor
            mc_pred = mc_pred * self.scale_factor

        ec_df = pd.DataFrame(ec_pred, columns=[f"{k}_EC" for k in INDICATORS])
        mc_df = pd.DataFrame(mc_pred, columns=[f"{k}_MC" for k in INDICATORS])
        tot_df = pd.DataFrame(ec_pred + mc_pred, columns=[f"{k}_TOT" for k in INDICATORS])

        out = pd.concat([df.reset_index(drop=True), ec_df, mc_df, tot_df], axis=1)
        return out
