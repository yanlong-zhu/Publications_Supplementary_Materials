#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Post-processing LCA report generator for slicer-exported G-code.

Typical use (PrusaSlicer):
- Add this script as a "Post-processing script" in:
  Print Settings -> Output options -> Post-processing scripts
- Example command (Windows):
  "C:\\Path\\to\\python.exe" "D:\\path\\post_lca_report.py"
PrusaSlicer will append the (temporary) gcode filepath as the LAST argument.

What it does:
1) Receives a gcode file path (last CLI arg).
2) Parses material type, filament mass [g], and print time from the gcode comments.
   (Robust to cases where these lines appear near the end of the file.)
3) Computes EC/MC/Total for GWP, FRS, OFHH, TA.
4) Writes an Excel report with the same basename as the exported gcode:
   <gcode_basename>_lca.xlsx
"""

import os
import re
import sys
from dataclasses import dataclass
from datetime import datetime
from collections import deque
from typing import Dict, Optional, Tuple, List

from openpyxl import Workbook
from openpyxl.styles import Font, Alignment
from openpyxl.utils import get_column_letter


# -----------------------------
# USER CONFIG: FACTORS & UNITS
# -----------------------------

# Electricity factors per minute (kg eq / min), used for EC = factor_per_min * time_min
ELEC_PER_MIN: Dict[str, float] = {
    "GWP": 0.00128232649,     # kg CO2 eq / min
    "FRS": 0.000191851766,    # kg oil eq / min
    "OFHH": 1.29550599e-06,   # kg NOx eq / min
    "TA": 2.64081803e-06,     # kg SO2 eq / min
}

# Material factors per kg (kg eq / kg), used for MC = factor_per_kg * mass_kg
# Replace with your exact table values if needed.
PLA_PER_KG: Dict[str, float] = {
    "GWP": 1.48,
    "FRS": 1.78,
    "OFHH": 0.0074,
    "TA": 0.0059,
}

# PETG proxy factors per kg (example: PET per-kg derived * 1.15).
# Replace if you use a different PETG mapping.
PETG_PROXY_PER_KG: Dict[str, float] = {
    "GWP": 3.146,
    "FRS": 1.770,
    "OFHH": 0.005008,
    "TA": 0.007740,
}

UNITS: Dict[str, str] = {
    "GWP": "kg CO₂ eq",
    "FRS": "kg oil eq",
    "OFHH": "kg NOx eq",
    "TA": "kg SO₂ eq",
}

INDICATORS: List[str] = ["GWP", "FRS", "OFHH", "TA"]


# -----------------------------
# DATA MODEL
# -----------------------------

@dataclass
class GcodeInfo:
    material_raw: str
    material_label: str
    mass_g: float
    time_min: float
    gcode_input_path: str
    gcode_exported_path: str


# -----------------------------
# PARSING HELPERS
# -----------------------------

def parse_time_to_minutes(text: str) -> Optional[float]:
    """
    Parses time strings like:
      '2h 29m 41s', '99m 10s', '1h 3m', '45m', '8981s'
    Returns minutes as float, or None if parsing fails.
    """
    s = text.strip().lower()

    # Common slicer format: '2h 29m 41s'
    h_match = re.search(r"(\d+(?:\.\d+)?)\s*h", s)
    m_match = re.search(r"(\d+(?:\.\d+)?)\s*m", s)
    s_match = re.search(r"(\d+(?:\.\d+)?)\s*s", s)

    if h_match or m_match or s_match:
        h = float(h_match.group(1)) if h_match else 0.0
        m = float(m_match.group(1)) if m_match else 0.0
        sec = float(s_match.group(1)) if s_match else 0.0
        return h * 60.0 + m + sec / 60.0

    # Fallback: only seconds like "8981s"
    only_s = re.match(r"^\s*(\d+(?:\.\d+)?)\s*s\s*$", s)
    if only_s:
        return float(only_s.group(1)) / 60.0

    return None


def read_head_and_tail_lines(path: str, head_n: int = 8000, tail_n: int = 8000) -> List[str]:
    """
    Reads first head_n lines and last tail_n lines from a text file.
    This avoids scanning the entire file for huge G-code outputs,
    and handles cases where summary lines appear near the end.
    """
    head_lines: List[str] = []
    tail_lines = deque(maxlen=tail_n)

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for i, line in enumerate(f):
            line_stripped = line.strip()
            if i < head_n:
                head_lines.append(line_stripped)
            tail_lines.append(line_stripped)

    return head_lines + list(tail_lines)


def extract_material_mass_time(gcode_path: str) -> Tuple[str, float, float]:
    """
    Extracts:
      - material string (raw)
      - filament mass in grams
      - print time in minutes
    from G-code comments.

    Supports typical PrusaSlicer fields, and is robust if fields are in head or tail.
    """
    lines = read_head_and_tail_lines(gcode_path, head_n=8000, tail_n=8000)

    material_raw: str = "UNKNOWN"
    mass_g: Optional[float] = None
    time_min: Optional[float] = None

    # Material patterns
    # Examples:
    #   ; filament_type = PLA
    #   ; filament_type = "PETG"
    #   ; filament_type[0] = PLA
    material_patterns = [
        re.compile(r";\s*filament_type(?:\[\d+\])?\s*=\s*\"?([A-Za-z0-9\-_]+)\"?", re.IGNORECASE),
        re.compile(r";\s*filament type\s*:\s*\"?([A-Za-z0-9\-_]+)\"?", re.IGNORECASE),
        re.compile(r";\s*material\s*=\s*\"?([A-Za-z0-9\-_]+)\"?", re.IGNORECASE),
    ]

    # Mass patterns (grams)
    # Examples:
    #   ; filament used [g] = 5.54
    #   ; total filament used [g] = 5.54
    mass_patterns = [
        re.compile(r";\s*total filament used\s*\[g\]\s*=\s*([0-9]*\.?[0-9]+)", re.IGNORECASE),
        re.compile(r";\s*filament used\s*\[g\]\s*=\s*([0-9]*\.?[0-9]+)", re.IGNORECASE),
    ]

    # Time patterns
    # Examples:
    #   ; estimated printing time (normal mode) = 2h 29m 41s
    #   ; estimated printing time = 1h 3m
    time_patterns = [
        re.compile(r";\s*estimated printing time.*?=\s*(.+)$", re.IGNORECASE),
        re.compile(r";\s*estimated print time.*?=\s*(.+)$", re.IGNORECASE),
        re.compile(r";\s*printing time.*?=\s*(.+)$", re.IGNORECASE),
    ]

    for line in lines:
        if material_raw == "UNKNOWN":
            for pat in material_patterns:
                m = pat.search(line)
                if m:
                    material_raw = m.group(1).strip()
                    break

        if mass_g is None:
            for pat in mass_patterns:
                m = pat.search(line)
                if m:
                    mass_g = float(m.group(1))
                    break

        if time_min is None:
            for pat in time_patterns:
                m = pat.search(line)
                if m:
                    candidate = m.group(1).strip()
                    parsed = parse_time_to_minutes(candidate)
                    if parsed is not None:
                        time_min = parsed
                        break

        if material_raw != "UNKNOWN" and mass_g is not None and time_min is not None:
            break

    if mass_g is None or time_min is None:
        raise RuntimeError(
            "Failed to parse G-code summary fields.\n"
            f"Parsed so far: material={material_raw}, mass_g={mass_g}, time_min={time_min}\n"
            "Tip: Open the G-code and search for lines like:\n"
            "  '; filament used [g] = ...' and '; estimated printing time ... = ...'\n"
            "If those lines exist but are not within the first/last 8000 lines, increase head_n/tail_n."
        )

    return material_raw, mass_g, time_min


# -----------------------------
# FACTOR SELECTION & COMPUTATION
# -----------------------------

def select_material_factors(material_raw: str) -> Tuple[str, Dict[str, float]]:
    """
    Maps raw material string to a factor dictionary.
    Adjust mapping if your slicer writes different names.
    """
    m = material_raw.upper()

    if "PLA" in m:
        return "PLA", PLA_PER_KG
    if "PETG" in m:
        return "PETG (proxy)", PETG_PROXY_PER_KG

    # Default fallback (explicitly labeled)
    return f"{material_raw} (treated as PLA)", PLA_PER_KG


def compute_ec_mc_total(mass_g: float, time_min: float, material_factors: Dict[str, float]) -> Dict[str, Dict[str, float]]:
    """
    Returns:
      { indicator: { 'EC': ..., 'MC': ..., 'Total': ... } }
    """
    mass_kg = mass_g / 1000.0
    out: Dict[str, Dict[str, float]] = {}

    for ind in INDICATORS:
        ec = ELEC_PER_MIN[ind] * time_min
        mc = material_factors[ind] * mass_kg
        out[ind] = {"EC": ec, "MC": mc, "Total": ec + mc}

    return out


# -----------------------------
# EXCEL REPORT WRITER
# -----------------------------

def autosize_columns(ws) -> None:
    for col in range(1, ws.max_column + 1):
        max_len = 0
        col_letter = get_column_letter(col)
        for row in range(1, ws.max_row + 1):
            v = ws.cell(row=row, column=col).value
            if v is None:
                continue
            max_len = max(max_len, len(str(v)))
        ws.column_dimensions[col_letter].width = min(max_len + 2, 48)


def format_number_cell(cell, value: float) -> None:
    cell.value = float(value)
    # Scientific notation for very small values, fixed otherwise
    if abs(value) < 1e-3:
        cell.number_format = "0.000E+00"
    else:
        cell.number_format = "0.000000"
    cell.alignment = Alignment(horizontal="right")


def write_excel_report(info: GcodeInfo, results: Dict[str, Dict[str, float]]) -> str:
    """
    Writes an Excel file named <gcode_basename>_lca.xlsx
    in the directory of the exported gcode (if known), otherwise next to input gcode.
    """
    export_dir = os.path.dirname(os.path.abspath(info.gcode_exported_path))
    base = os.path.splitext(os.path.basename(info.gcode_exported_path))[0]
    out_path = os.path.join(export_dir, f"{base}_lca.xlsx")

    wb = Workbook()
    ws = wb.active
    ws.title = "LCA"

    bold = Font(bold=True)

    # Header metadata
    ws["A1"] = "G-code file"
    ws["B1"] = os.path.basename(info.gcode_exported_path)
    ws["A2"] = "Material (parsed)"
    ws["B2"] = info.material_raw
    ws["A3"] = "Material (used for factors)"
    ws["B3"] = info.material_label
    ws["A4"] = "Mass"
    ws["B4"] = info.mass_g
    ws["C4"] = "g"
    ws["A5"] = "Time"
    ws["B5"] = info.time_min
    ws["C5"] = "min"
    ws["A6"] = "Generated"
    ws["B6"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    for r in range(1, 7):
        ws[f"A{r}"].font = bold
        ws[f"A{r}"].alignment = Alignment(horizontal="left")

    # Main results table
    start_row = 8
    headers = ["Indicator", "Unit", "EC (electricity)", "MC (material)", "Total"]
    for c, h in enumerate(headers, start=1):
        cell = ws.cell(row=start_row, column=c, value=h)
        cell.font = bold
        cell.alignment = Alignment(horizontal="center")

    for i, ind in enumerate(INDICATORS, start=1):
        r = start_row + i
        ws.cell(row=r, column=1, value=ind)
        ws.cell(row=r, column=2, value=UNITS[ind])

        ec = results[ind]["EC"]
        mc = results[ind]["MC"]
        total = results[ind]["Total"]

        format_number_cell(ws.cell(row=r, column=3), ec)
        format_number_cell(ws.cell(row=r, column=4), mc)

        total_cell = ws.cell(row=r, column=5)
        format_number_cell(total_cell, total)
        total_cell.font = bold

    # Notes (optional but useful for paper reproducibility)
    note_row = start_row + len(INDICATORS) + 2
    ws.cell(row=note_row, column=1, value="Notes").font = bold
    ws.cell(row=note_row + 1, column=1, value="Total = EC + MC (per indicator).")
    ws.cell(row=note_row + 2, column=1, value="EC uses fixed per-minute electricity factors.")
    ws.cell(row=note_row + 3, column=1, value="MC uses per-kg material factors (PLA or PETG proxy).")

    autosize_columns(ws)
    wb.save(out_path)
    return out_path


# -----------------------------
# PATH RESOLUTION (PRUSASLICER)
# -----------------------------

def resolve_exported_gcode_path(gcode_input_path: str) -> str:
    """
    Best-effort resolution of the *final exported* gcode path.

    PrusaSlicer can provide SLIC3R_PP_OUTPUT_NAME via environment variable.
    Sometimes it contains a full path, sometimes only a name. If it is not usable,
    we fall back to the input (temporary) gcode path.
    """
    out_name = os.environ.get("SLIC3R_PP_OUTPUT_NAME", "").strip()
    if out_name:
        # If it looks like a path (absolute or has a directory component), use it.
        if os.path.isabs(out_name) or os.path.dirname(out_name):
            return out_name
        # If it's only a filename, place it next to the input gcode.
        return os.path.join(os.path.dirname(os.path.abspath(gcode_input_path)), out_name)

    return gcode_input_path


# -----------------------------
# MAIN
# -----------------------------

def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: post_lca_report.py <path_to_gcode>")
        print("Note: In PrusaSlicer post-processing, the gcode path is appended as the LAST argument.")
        return 2

    gcode_path = sys.argv[-1]
    if not os.path.isfile(gcode_path):
        print(f"ERROR: G-code file not found: {gcode_path}")
        return 2

    material_raw, mass_g, time_min = extract_material_mass_time(gcode_path)
    material_label, mat_factors = select_material_factors(material_raw)

    exported_path = resolve_exported_gcode_path(gcode_path)

    info = GcodeInfo(
        material_raw=material_raw,
        material_label=material_label,
        mass_g=mass_g,
        time_min=time_min,
        gcode_input_path=gcode_path,
        gcode_exported_path=exported_path,
    )

    results = compute_ec_mc_total(mass_g=info.mass_g, time_min=info.time_min, material_factors=mat_factors)
    out_xlsx = write_excel_report(info, results)

    print("[LCA] Parsed:")
    print(f"  material_raw = {info.material_raw}")
    print(f"  material_used = {info.material_label}")
    print(f"  mass_g = {info.mass_g}")
    print(f"  time_min = {info.time_min}")
    print(f"[LCA] Report saved: {out_xlsx}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
