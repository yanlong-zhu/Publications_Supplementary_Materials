# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager

# === 0. Fonts: register Roboto from Windows ==============================
for fp in [
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf",
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf",
]:
    try:
        font_manager.fontManager.addfont(fp)
    except Exception:
        pass

plt.rcParams["font.family"] = "Roboto"
plt.rcParams["font.sans-serif"] = ["Roboto"]

# === 1. Load data ========================================================
# Input file: MAPE of ±10% perturbations for each printing parameter
input_path = r"D:\soft\python\LHS\figure11e_perturbation_mape.xlsx"
df = pd.read_excel(input_path)

# === 2. Parameters and indicators =======================================
parameters = ["Print Speed", "Layer Height", "Infill Density", "Raster Angle"]
indicators = ["ΔGWP_%", "ΔFRS_%", "ΔOFHH_%", "ΔTA_%"]
indicator_labels = ["GWP", "FRS", "OFHH", "TA"]

# === 3. Colors (RGBA, alpha = 0.6) ======================================
colors = [
    (31 / 255, 119 / 255, 180 / 255, 0.6),   # GWP  – blue
    (254 / 255, 127 / 255, 15 / 255, 0.6),   # FRS  – orange
    (44 / 255, 160 / 255, 44 / 255, 0.6),    # OFHH – green
    (214 / 255, 39 / 255, 40 / 255, 0.6),    # TA   – red
]

# === 4. Plotting =========================================================
x = np.arange(len(parameters))
bar_width = 0.18

fig, ax = plt.subplots(figsize=(8, 6), facecolor="white")

for i, indicator in enumerate(indicators):
    values = df[indicator].values
    centers = x + (i - 1.5) * bar_width  # shift groups horizontally
    ax.bar(
        centers,
        values,
        width=bar_width,
        color=colors[i],
        label=indicator_labels[i],
    )

    # value labels on top of each bar
    for cx, v in zip(centers, values):
        ax.text(
            cx,
            v + 0.05,
            f"{v:.1f}",
            ha="center",
            va="bottom",
            fontsize=12,
        )

# === 5. Axes settings ====================================================
ax.set_xlabel("Printing Parameter", fontsize=19)
ax.set_ylabel("MAPE (%)", fontsize=19)
ax.set_xticks(x)
ax.set_xticklabels(parameters, fontsize=15)
ax.tick_params(axis="both", labelsize=15)

# === 6. Axis limits & frame linewidth ===================================
ax.set_ylim(0, 5.3)
for spine in ["left", "bottom", "top", "right"]:
    ax.spines[spine].set_visible(True)
    ax.spines[spine].set_linewidth(1.0)

# Remove top/right ticks but keep frame
ax.tick_params(top=False, right=False)

# === 7. Legend ===========================================================
ax.legend(fontsize=15, frameon=False)

# === 8. Save figure ======================================================
output_path = r"D:\soft\python\LHS\figure11e_perturbation_mape.png"
plt.tight_layout()
plt.savefig(
    output_path,
    dpi=600,
    bbox_inches="tight",
    facecolor="white",
)
plt.close()

print(f"Figure 11e saved to: {output_path}")
