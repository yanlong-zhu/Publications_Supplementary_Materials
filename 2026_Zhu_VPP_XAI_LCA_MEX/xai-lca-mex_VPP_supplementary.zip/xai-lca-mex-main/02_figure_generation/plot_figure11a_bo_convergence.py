# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FuncFormatter
from matplotlib import font_manager

"""
Figure 11a: BO convergence of the normalised combined objective
over 50 iterations across 10 runs.

- The blue line shows the across-run mean per iteration.
- The orange band shows ±1 standard deviation across runs.
- RSD (%) is computed over the final 10 iterations.
"""

# --- Font settings: Roboto ------------------------------------------------
for fp in [
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf",
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf",
]:
    try:
        font_manager.fontManager.addfont(fp)
    except Exception:
        pass

plt.rcParams["font.family"] = "Roboto"
plt.rcParams["font.sans-serif"] = ["Roboto"]

# --- Input / output paths -------------------------------------------------
input_path = r"D:\soft\python\LHS\figure11a_bo_convergence_history.xlsx"
output_path = r"D:\soft\python\LHS\figure11a_bo_convergence.png"

# --- Load data ------------------------------------------------------------
df = pd.read_excel(input_path)

# "Iteration" column, remaining columns are objective values from each run
iterations = df["Iteration"]
df_data = df.drop(columns="Iteration")

# Across-run mean and standard deviation per iteration
mean_values = df_data.mean(axis=1)
std_values = df_data.std(axis=1)

# --- RSD over the final 10 iterations ------------------------------------
tail = mean_values.iloc[-10:]
rsd = (tail.std() / tail.mean()) * 100.0

# --- Plot -----------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8, 6), facecolor="white")

# Mean curve and ±1 SD band
ax.plot(
    iterations,
    mean_values,
    color="#1f77b4",
    linewidth=2.5,
    label="Average objective value",
)
ax.fill_between(
    iterations,
    mean_values - std_values,
    mean_values + std_values,
    color="#ff7f0e",
    alpha=0.2,
    label="±1 SD",
)

# Dummy handle for RSD in legend
ax.plot([], [], " ", label=f"RSD = {rsd:.2f}%")

# Axis labels
ax.set_xlabel("Iteration", fontsize=19)
ax.set_ylabel("Normalised combined objective", fontsize=19)

# Optional y-axis scaling for nicer numbers (here ×1e2)
formatter = FuncFormatter(lambda x, _: f"{x * 1e2:.1f}")
ax.yaxis.set_major_formatter(formatter)

# Ticks and frame
ax.tick_params(axis="both", which="major", labelsize=15, direction="in")
for spine in ax.spines.values():
    spine.set_linewidth(1.5)
ax.tick_params(axis="x", top=False)
ax.tick_params(axis="y", right=False)

# Legend
ax.legend(loc="upper right", fontsize=13, frameon=False)

# Layout and save
plt.subplots_adjust(left=0.15, top=0.88)
plt.tight_layout()
plt.savefig(output_path, dpi=600)
plt.close()

print(f"[SAVE] Figure 11a saved to: {output_path}")
