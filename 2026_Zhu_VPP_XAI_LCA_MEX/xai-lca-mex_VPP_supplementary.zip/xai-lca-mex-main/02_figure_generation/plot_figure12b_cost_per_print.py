# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from matplotlib import font_manager

"""
Figure 12b: Cost per print (=C/part), decomposed into
material cost (MC) and electricity cost (EC).

Input file: figure12b_cost_per_print.xlsx

Expected format:
- Column 0: group labels (e.g. Group1, Group2, Group3, Group4)
- One column starting with "Mass price"  -> MC cost (€/part)
- One column starting with "EC price"    -> EC cost (€/part)
- One column starting with "All price"   -> total cost (€/part)
- First 4 rows: mean values
- Next 4 rows: standard deviations
"""

# =========================
# Font: Roboto
# =========================
for fp in [
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf",
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf",
]:
    try:
        font_manager.fontManager.addfont(fp)
    except Exception:
        pass

plt.rcParams["font.family"] = "Roboto"
plt.rcParams["font.sans-serif"] = ["Roboto"]

# =========================
# Paths
# =========================
base_dir = Path(r"D:\soft\python\LHS")
in_xlsx = base_dir / "figure12b_cost_per_print.xlsx"
out_png = base_dir / "figure12b_cost_per_print.png"
out_pdf = base_dir / "figure12b_cost_per_print.pdf"

# =========================
# Load data
# =========================
df = pd.read_excel(in_xlsx, sheet_name=0)

# Identify columns
label_col = df.columns[0]
mc_col = [c for c in df.columns if str(c).strip().lower().startswith("mass price")][0]
ec_col = [c for c in df.columns if str(c).strip().lower().startswith("ec price")][0]
all_col = [c for c in df.columns if str(c).strip().lower().startswith("all price")][0]

# First 4 rows = mean, next 4 rows = SD
mean_df = df.iloc[:4].copy()
sd_df = df.iloc[4:].copy()

mean_df = mean_df.rename(columns={label_col: "group"})
sd_df = sd_df.rename(columns={label_col: "group"})
mean_df["group"] = mean_df["group"].astype(str).str.lower()
sd_df["group"] = sd_df["group"].astype(str).str.lower()

order = ["group1", "group2", "group3", "group4"]
mean_df = mean_df.set_index("group").loc[order].reset_index()
sd_df = sd_df.set_index("group").loc[order].reset_index()

# Extract arrays
mc_mean = mean_df[mc_col].to_numpy(dtype=float)
ec_mean = mean_df[ec_col].to_numpy(dtype=float)
tot_mean = mean_df[all_col].to_numpy(dtype=float)
mc_sd = sd_df[mc_col].to_numpy(dtype=float)
ec_sd = sd_df[ec_col].to_numpy(dtype=float)
tot_sd = sd_df[all_col].to_numpy(dtype=float)

xlabels = ["Group 1", "Group 2", "Group 3", "BO optimum"]

# =========================
# Plot (stacked bars)
# =========================
fig, ax = plt.subplots(figsize=(8.6, 5.0), facecolor="white")
x = np.arange(len(xlabels))
barw = 0.58

# Bars: no edge, alpha = 0.6
mc_bar = ax.bar(
    x,
    mc_mean,
    width=barw,
    label="Material (MC)",
    color=(31 / 255, 119 / 255, 180 / 255, 0.6),
    edgecolor="none",
    linewidth=0,
)
ec_bar = ax.bar(
    x,
    ec_mean,
    width=barw,
    bottom=mc_mean,
    label="Electricity (EC)",
    color=(255 / 255, 127 / 255, 14 / 255, 0.6),
    edgecolor="none",
    linewidth=0,
)

# Error bars for total cost
ax.errorbar(
    x,
    tot_mean,
    yerr=tot_sd,
    fmt="none",
    ecolor="black",
    elinewidth=1,
    capsize=10,
    capthick=1,
    zorder=3,
)

# Total cost text above bars
top_offset = 0.0025
for i, val in enumerate(tot_mean):
    ax.text(
        x[i],
        min(val + top_offset, 0.12),
        f"{val:.3f}",
        ha="center",
        va="bottom",
        fontsize=14,
    )

# Percentage labels inside bars
for i, (m_mc, m_ec) in enumerate(zip(mc_mean, ec_mean)):
    t = m_mc + m_ec
    if t <= 0:
        continue
    mc_pct = m_mc / t * 100.0
    ec_pct = 100.0 - mc_pct
    ax.text(
        x[i],
        m_mc / 2.0,
        f"{mc_pct:.1f}%",
        ha="center",
        va="center",
        fontsize=14,
    )
    ax.text(
        x[i],
        m_mc + m_ec / 2.0,
        f"{ec_pct:.1f}%",
        ha="center",
        va="center",
        fontsize=14,
    )

# Axes and style
ax.set_xticks(x)
ax.set_xticklabels(xlabels, fontsize=15)
ax.set_xlabel("Validation setting", fontsize=19)
ax.set_ylabel("Cost per print (€)", fontsize=19)
ax.set_ylim(0, 0.125)
ax.tick_params(axis="both", direction="in", labelsize=15, length=4)

# Frame
for spine in ["top", "right", "left", "bottom"]:
    ax.spines[spine].set_visible(True)
    ax.spines[spine].set_linewidth(1.5)
    ax.spines[spine].set_color("black")

# Legend
ax.legend(
    handles=[mc_bar, ec_bar],
    labels=["MC", "EC"],
    fontsize=16,
    frameon=False,
    loc="upper right",
)

plt.tight_layout()
fig.savefig(out_png, dpi=600, bbox_inches="tight", facecolor="white")
fig.savefig(out_pdf, dpi=600, bbox_inches="tight", facecolor="white")
plt.close()

print(f"Saved: {out_png}\nSaved: {out_pdf}")
