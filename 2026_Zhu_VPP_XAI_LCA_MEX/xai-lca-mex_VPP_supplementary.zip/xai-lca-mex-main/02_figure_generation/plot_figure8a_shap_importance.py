import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager

# ========= Font: load Roboto on your local machine =========
font_paths = [
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf",
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf",
]
for fp in font_paths:
    if os.path.exists(fp):
        font_manager.fontManager.addfont(fp)

plt.rcParams["font.family"] = "Roboto"
plt.rcParams["font.sans-serif"] = ["Roboto"]

# ========= Paths (change these to your own folder if needed) =========
# Input file: aggregated SHAP importance data for the four parameters
input_path = r"D:\soft\python\LHS\figure8_shap_importance_data.xlsx"
# Output file: bar chart for Figure 8a
output_path = r"D:\soft\python\LHS\figure8_shap_importance.png"

# ========= Read data =========
df = pd.read_excel(input_path)

# First column: indicator labels (e.g. GWP, FRS, OFHH, TA)
labels = df.iloc[:, 0]
# Remaining columns: relative importance (%) of each parameter
data = df.iloc[:, 1:]

# Fixed column order and colors (including alpha = 0.6)
column_labels = ["Print Speed", "Layer Height", "Infill Density", "Raster Angle"]
colors = [
    (31 / 255, 119 / 255, 180 / 255, 0.6),  # blue   – Print Speed
    (254 / 255, 127 / 255, 15 / 255, 0.6),  # orange – Layer Height
    (44 / 255, 160 / 255, 44 / 255, 0.6),   # green  – Infill Density
    (214 / 255, 39 / 255, 40 / 255, 0.6),   # red    – Raster Angle
]
data = data[column_labels]

# ========= Axes / canvas =========
x = np.arange(len(labels))
bar_width = 0.6

fig, ax = plt.subplots(figsize=(7, 5))
bottom = np.zeros(len(labels))

# ========= Plot stacked bars + value labels =========
for i, col in enumerate(column_labels):
    vals = data.iloc[:, i].values
    ax.bar(
        x,
        vals,
        width=bar_width,
        bottom=bottom,
        label=col,
        color=colors[i],
        edgecolor="none",
    )

    for xi, vi, bi in zip(x, vals, bottom):
        # Default text position in the middle of each segment
        if col == "Infill Density":
            # Shift green labels slightly downward to avoid overlap with red
            text_y = bi + vi / 2 - 2
        elif col == "Layer Height":
            # Shift orange labels slightly upward to highlight layer height
            text_y = bi + vi / 2 + 1
        else:
            text_y = bi + vi / 2

        ax.text(
            xi + bar_width * 0.10,
            text_y,
            f"{vi:.1f}",
            ha="center",
            va="center",
            color="black",
            fontsize=14,
        )

    bottom += vals

# ========= Axes / ticks =========
ax.set_ylabel("Relative Importance (%)", fontsize=19)
ax.set_xlabel("LCA Indicators", fontsize=19)
ax.set_ylim(-3, 103)
ax.set_xticks(x)
ax.set_xticklabels(labels, fontsize=15)
ax.tick_params(axis="y", labelsize=15, direction="in")

# ========= X range & legend =========
x_max = x[-1] + bar_width / 2
x_limit = x_max * 1.3
ax.set_xlim(-0.5, x_limit)

ax.legend(
    fontsize=10,
    frameon=False,
    loc="upper left",
    bbox_to_anchor=(x_limit - 1.02, 90),  # move left/right by adjusting -1.02
    bbox_transform=ax.transData,
    borderaxespad=0.0,
)

# ========= Frame / linewidth =========
for spine in ax.spines.values():
    spine.set_linewidth(1.2)
ax.tick_params(axis="both", width=1.2, direction="in")

# ========= Save figure =========
plt.subplots_adjust(left=0.12, right=0.95, top=0.90, bottom=0.12)
plt.savefig(output_path, dpi=600, bbox_inches="tight", pad_inches=0.02)
plt.close()

print(f"Saved Figure 8a to: {output_path}")
