# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager

"""
Figure 12c: slicer-based material transfer.

Grouped bar chart with error bars showing MAPE (%) for
GWP, FRS, OFHH and TA across different materials (PLA, ABS, PETG).

Input format (figure12c_material_transfer_mape.xlsx):
- Column 0: "Indicator" (GWP, FRS, OFHH, TA, then again for SD rows)
- Other columns: one per material (e.g. PLA, ABS, PETG)
- First 4 rows: mean MAPE (%)
- Next 4 rows: standard deviation of MAPE (%)
"""

# =========================
# Font settings: Roboto
# =========================
for fp in [
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf",
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf",
]:
    try:
        font_manager.fontManager.addfont(fp)
    except Exception:
        pass

plt.rcParams["font.family"] = "Roboto"
plt.rcParams["font.sans-serif"] = ["Roboto"]

# =========================
# 1) Load combined table
# =========================
path = r"D:\soft\python\LHS\figure12c_material_transfer_mape.xlsx"
df = pd.read_excel(path, sheet_name="Sheet1")

# Drop extra columns if present
for col in ("name",):
    if col in df.columns:
        df = df.drop(columns=[col])

materials = [c for c in df.columns if c != "Indicator"]

# First 4 rows: means; next 4 rows: SD
means_block = df.iloc[0:4].set_index("Indicator")[materials]
sd_block    = df.iloc[4:8].set_index("Indicator")[materials]

# Desired indicator order
indicators_order = ["GWP", "FRS", "OFHH", "TA"]
means_block = means_block.loc[indicators_order]
sd_block    = sd_block.loc[indicators_order]

# =========================
# 2) Plot (grouped bars + error bars)
# =========================
x = np.arange(len(materials))
bar_width = 0.18

fig, ax = plt.subplots(figsize=(8.2, 5), facecolor="white")

# Custom colors (RGBA, alpha = 0.6)
colors = [
    (31/255, 119/255, 180/255, 0.6),   # GWP – blue
    (255/255, 127/255, 14/255, 0.6),   # FRS – orange
    (44/255, 160/255, 44/255, 0.6),    # OFHH – green
    (214/255, 39/255, 40/255, 0.6),    # TA – red
]

for i, ind in enumerate(indicators_order):
    y    = means_block.loc[ind].values.astype(float)
    yerr = sd_block.loc[ind].values.astype(float)
    ax.bar(
        x + i * bar_width,
        y,
        width=bar_width,
        label=ind,
        color=colors[i],
        edgecolor="none",
        yerr=yerr,
        capsize=3,
    )

# =========================
# 3) Axes / style / export
# =========================
ax.set_xticks(x + 1.5 * bar_width)
ax.set_xticklabels(materials, fontsize=15)

ax.set_xlabel("Different materials", fontsize=19)
ax.set_ylabel("MAPE (%)", fontsize=19)

ax.set_ylim(0, 4.5)
ax.set_yticks(np.arange(0.0, 4.5 + 0.5, 1.0))
ax.tick_params(axis="both", direction="in", labelsize=15)

# Frame style
for spine in ["top", "right", "left", "bottom"]:
    ax.spines[spine].set_visible(True)
    ax.spines[spine].set_linewidth(1.5)
    ax.spines[spine].set_color("black")

# Legend (top-right)
ax.legend(fontsize=16, frameon=False, loc="upper right")

fig.tight_layout()

# Save figure
output_path = r"D:\soft\python\LHS\figure12c_material_transfer_mape.png"
plt.savefig(output_path, dpi=600, facecolor="white")
plt.close()

print(f"Saved: {output_path}")
