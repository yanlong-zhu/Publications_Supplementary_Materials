# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib import font_manager
import joblib
from scipy.interpolate import PchipInterpolator

# --- Step 0: Paths ----------------------------------------------------------
ecrm_path = r"D:\soft\python\LHS\ECRM.pkl"
mcrm_path = r"D:\soft\python\LHS\MCRM.pkl"
save_path = r"D:\soft\python\LHS\PDP_PrintSpeed_GWP_Shaded.png"

# --- Fonts: Roboto ----------------------------------------------------------
for fp in [
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf",
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf",
]:
    try:
        font_manager.fontManager.addfont(fp)
    except Exception:
        pass
plt.rcParams["font.family"] = "Roboto"
plt.rcParams["font.sans-serif"] = ["Roboto"]

# --- Colors & alpha ---------------------------------------------------------
BLUE = "#1f77b4"
ORANGE = "#ff7f0e"
ALPHA_LINE = 0.6
ALPHA_SHADE = 0.2

# --- Step 1: Fixed parameters ----------------------------------------------
fixed_layer_height = 0.2
fixed_infill_density = 60
fixed_grating_angle = 45
print_speeds = [20, 40, 60, 80, 100, 120, 140]

# --- KEY: scale model outputs ONCE (no display scaling) ---------------------
SCALE_FACTOR = 80.0 / 27.0

# --- Step 2: Load models ----------------------------------------------------
ecrm_model = joblib.load(ecrm_path)
mcrm_model = joblib.load(mcrm_path)

# --- Step 3: Build PDP input (keep your column names) -----------------------
pdp_df = pd.DataFrame({
    "Print_Speed": print_speeds,
    "Layer_Height": fixed_layer_height,
    "Infill_Density": fixed_infill_density,
    "Grating angle": fixed_grating_angle,   # keep the space
})

# --- Step 4: Predict and rescale outputs once -------------------------------
y_pred_ec = ecrm_model.predict(pdp_df)[:, 0]
y_pred_mc = mcrm_model.predict(pdp_df)[:, 0]
y_pred_sum = (y_pred_ec + y_pred_mc) * SCALE_FACTOR   # ✅ only change

# --- Step 5: PCHIP interpolation -------------------------------------------
pchip = PchipInterpolator(print_speeds, y_pred_sum)
x_smooth = np.linspace(min(print_speeds), max(print_speeds), 300)
y_smooth = pchip(x_smooth)

# --- Step 6: Delta ----------------------------------------------------------
delta_y = np.max(y_smooth) - np.min(y_smooth)
delta_text = f"ΔGWP = {delta_y:.4f}"

# --- Step 7: Plot -----------------------------------------------------------
plt.figure(figsize=(7, 5), facecolor="white")

plt.plot(x_smooth, y_smooth, color=ORANGE, linewidth=3, alpha=ALPHA_LINE)
plt.axvspan(80, 140, color=BLUE, alpha=ALPHA_SHADE)

plt.text(
    0.45, 0.97, delta_text,
    transform=plt.gca().transAxes,
    fontsize=17, ha="right", va="top"
)

plt.xlabel("Print Speed (mm/s)", fontsize=19)
plt.ylabel("GWP (kg CO$_2$ eq)", fontsize=19)

plt.xticks(fontsize=15)
plt.yticks(fontsize=15)
plt.tick_params(axis="x", direction="in", bottom=True)
plt.tick_params(axis="y", direction="in", left=True)

# keep your original tick formatting (NO display scaling)
plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter("%.3f"))
plt.gca().yaxis.set_major_locator(ticker.MultipleLocator(0.01))

for spine in ["left", "bottom", "right", "top"]:
    plt.gca().spines[spine].set_linewidth(1.5)

plt.grid(False)
plt.tight_layout()
plt.savefig(save_path, dpi=600, format="png", facecolor="white")
plt.close()

print(f"PDP saved to: {save_path}")
