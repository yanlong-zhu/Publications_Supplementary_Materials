import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager

# -------- Font: load Roboto installed on Windows --------
font_paths = [
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf",
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf",
]
for fp in font_paths:
    if os.path.exists(fp):
        font_manager.fontManager.addfont(fp)

plt.rcParams["font.family"] = "Roboto"
plt.rcParams["font.sans-serif"] = ["Roboto"]

# -------- Paths (change to your own folder if needed) --------
input_path = r"D:\soft\python\LHS\figure7_data.csv"
output_path = r"D:\soft\python\LHS\figure7_mape_comparison.png"

# -------- Load data --------
df = pd.read_csv(input_path)

# X-axis labels (e.g. GWP, FRS, OFHH, TA)
x_labels = df["Indicator"].tolist()

# Mean MAPE and standard error for the two models
lc_values = df["Mean Relative Error (LC)"]
lc_errors = df["Standard Error (LC)"]
ecmc_values = df["Mean Relative Error (EC/MC)"]
ecmc_errors = df["Standard Error (EC/MC)"]

# Colors with alpha = 0.6
colors = {
    "LC": (31 / 255, 119 / 255, 180 / 255, 0.6),     # blue – Direct-RFM
    "EC/MC": (254 / 255, 127 / 255, 15 / 255, 0.6),  # orange – EC/MC-RFM
}

# -------- Create figure --------
fig, ax = plt.subplots(figsize=(7.5, 5), facecolor="white")

# Bar positions and width
x = np.arange(len(x_labels))
width = 0.35

# Plot bars (no bar edge)
ax.bar(
    x - width / 2,
    lc_values,
    width,
    yerr=lc_errors,
    capsize=5,
    label="Direct-RFM",
    color=colors["LC"],
    edgecolor="none",
)

ax.bar(
    x + width / 2,
    ecmc_values,
    width,
    yerr=ecmc_errors,
    capsize=5,
    label="EC/MC-RFM",
    color=colors["EC/MC"],
    edgecolor="none",
)

# Axis labels
ax.set_ylabel("MAPE (%)", fontsize=19)
ax.set_xlabel("LCA Indicators", fontsize=19)

ax.set_xticks(x)
ax.set_xticklabels(x_labels, fontsize=15)
ax.tick_params(axis="both", labelsize=15, direction="in")

# -------- Frame: keep all four spines, linewidth = 1.0 --------
for spine in ax.spines.values():
    spine.set_linewidth(1.0)
ax.spines["top"].set_visible(True)
ax.spines["right"].set_visible(True)

# Legend
ax.legend(loc="upper right", fontsize=15, frameon=False)

# -------- Save figure --------
plt.tight_layout()
plt.savefig(output_path, dpi=600)
plt.close()

print(f"Figure 7 saved to: {output_path}")
