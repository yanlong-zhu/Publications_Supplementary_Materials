# Figure generation (Figures 6–12)

This folder contains the **data tables and Python scripts** used to
generate Figures 6–12 in the paper

> _[Towards Sustainable Material-Extrusion Additive Manufacturing: Explainable AI Analysis of Printing Parameter Effects on Life Cycle Assessment ]_  
> Yanlong Zhu et al., [Journal, Year].

All figures are generated from **static data tables** (CSV/XLSX) plus
the trained models in `../01_model_building/` where needed.

---

## 1. Environment

All scripts are standard Python scripts and rely on the following
packages:

- `python` ≥ 3.1 
- `pandas`  
- `numpy`  
- `matplotlib`  
- `seaborn` (only for the heatmap in Figure 11f)  
- `scipy` (for interpolation in the response surface / PDP)  
- `scikit-learn` (metrics only, e.g. R², MAPE)  
- `joblib` (to load the trained RF models from `01_model_building`)

You can install everything with:

```bash
pip install pandas numpy matplotlib seaborn scipy scikit-learn joblib

Paths:
Several scripts assume that this folder lives inside the repository
root (e.g. xai-lca-mex/02_figure_generation/) and that the trained
models and prediction tables in ../01_model_building/ are available.
If you move files, please adjust the path constants at the top of each
script.


---

## 2. File overview

### 2.1 Data tables

These files contain the processed numerical data used for plotting:

figure6_pred_vs_actual_data.csv
Predicted vs. actual values of the four LCA indicators (GWP, FRS,
OFHH, TA) for the validation set.

figure7_data.csv
Comparison between Direct-RFM and EC/MC-RFM in terms of mean relative
error and standard error for each indicator.

figure8_shap_importance_data.xlsx
Global SHAP importance values for GWP, FRS, OFHH and TA (used in
Figure 8a).

figure9a_surface_data.xlsx (optional, if present)
Sparse grid used for the GWP response surface in Figure 9a.
Alternatively, the script loads the RF models and generates the
surface directly from the models and the parameter ranges.

figure11a_bo_convergence_history.xlsx
History of the normalised combined objective for 10 BO runs
(columns = runs, rows = iterations).

figure11c_optima_scatter_data.xlsx
Locations of the 50 per-run optima (5 objectives × 10 runs) in
parameter space plus predicted GWP.

figure11e_perturbation_mape.xlsx
MAPE (%) for ±10 % one-at-a-time perturbations around the selected
BO-optimal parameter set.

figure11f_ratio_to_bo_optimum.xlsx
Ratios of the interpretation set’s min/mean/max to the BO optimum for
each indicator (used for the heatmap in Figure 11f).

figure12b_cost_per_print.xlsx
Mean and standard deviation of cost per print (C/part), decomposed
into material cost (MC) and electricity cost (EC) for each validation
setting.

figure12c_material_transfer_mape.xlsx
Slicer-based material transfer results: mean MAPE (%) and standard
deviation for GWP, FRS, OFHH and TA across different materials
(PLA, ABS, PETG).

```

Additional spreadsheets for other panels (e.g. Figures 12a and 12d)
can be added in the same format as figure12c_material_transfer_mape.xlsx
and plotted with the generic grouped-bar script described below.

### 2.2 Plotting scripts

Each script reads one or more of the above data tables (and, where
needed, the RF models from ../01_model_building/) and writes the
corresponding figure to PNG/PDF.

plot_figure6_pred_vs_actual.py
Reproduces Figure 6 (predicted vs. actual scatter plots for
GWP, FRS, OFHH and TA; one PNG per indicator).
Uses figure6_pred_vs_actual_data.csv.

plot_figure7.py
Reproduces Figure 7 (double-bar comparison of Direct-RFM vs
EC/MC-RFM with error bars).
Uses figure7_data.csv.

plot_figure8a_shap_importance.py
Reproduces Figure 8a (global SHAP importance stacked bar chart).
Uses figure8_shap_importance_data.xlsx.

plot_figure9a_surface.py
Reproduces Figure 9a (GWP response surface / contour plot as a
function of print speed and layer height).
Uses the EC-RFM and MC-RFM models from ../01_model_building/
and a sparse grid over the parameter space.

plot_figure10a_pdp_layer_height.py
Reproduces Figure 10a (PDP-style curve of GWP vs. layer height with
highlighted high-LH region and ΔGWP annotation).
Uses the EC-RM/MC-RM models from ../01_model_building/.

plot_figure11a_bo_convergence.py
Reproduces Figure 11a (BO convergence of the normalised combined
objective with ±1 SD band and RSD over the last 10 iterations).
Uses figure11a_bo_convergence_history.xlsx.

plot_figure11c_optima_scatter.py
Reproduces Figure 11c (scatter plot of the 50 BO optima in the
layer-height vs infill-density plane, coloured by GWP and with
optimal / second-best / near-optimal sets highlighted).
Uses figure11c_optima_scatter_data.xlsx.

plot_figure11e_perturbation_mape.py
Reproduces Figure 11e (MAPE (%) for ±10 % one-at-a-time
perturbations of each printing parameter).
Uses figure11e_perturbation_mape.xlsx.

plot_figure11f_ratio_heatmap.py
Reproduces Figure 11f (heatmap of interpretation-set
min/mean/max vs. BO optimum, “ratio to BO optimum”).
Uses figure11f_ratio_to_bo_optimum.xlsx.

plot_figure12b_cost_per_print.py
Reproduces Figure 12b (stacked bar chart of cost per print,
with MC/EC breakdown, error bars on the total and percentage labels
inside bars).
Uses figure12b_cost_per_print.xlsx.

plot_figure12c_material_transfer.py
Reproduces Figure 12c (grouped bar chart with error bars showing
material-transfer MAPE for PLA/ABS/PETG).
Uses figure12c_material_transfer_mape.xlsx.

The script is written as a generic grouped-bar + error-bar plot
and can also be reused for Figures 12a and 12d if
additional spreadsheets are provided in the same format.

---

## 3. How to run

From the repository root:

cd 02_figure_generation

 Example: reproduce Figure 11a
python plot_figure11a_bo_convergence.py

 Example: reproduce Figure 12b
python plot_figure12b_cost_per_print.py

Each script writes its output to the paths defined at the top of the
file (typically PNG and/or PDF). If you prefer different locations,
simply edit the output_path variables in the corresponding script.

---

## 4. Notes

All figures use Roboto (or Times New Roman where explicitly set)
for consistency with the paper; if Roboto is not installed on your
system, matplotlib will silently fall back to a default sans-serif
font.

This directory focuses on figure generation.
It uses processed datasets and trained models from 01_model_building.
The raw printer G-code files and the full SHAP analysis scripts are not stored here due to size and machine-specific dependencies, but can be shared on reasonable request.

For questions or issues, please see the contact information in
the main repository README.md.
