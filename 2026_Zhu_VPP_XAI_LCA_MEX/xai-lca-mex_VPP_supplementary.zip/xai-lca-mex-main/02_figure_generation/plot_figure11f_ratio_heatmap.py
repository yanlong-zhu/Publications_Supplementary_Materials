# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import font_manager

"""
Figure 11f: heatmap of the ratio between the interpretation set
(min / mean / max) and the BO optimum for each indicator.

Values > 1 indicate that the statistic (min/mean/max) is worse
(higher impact) than the BO optimum.
"""

# --- Font settings: Roboto ------------------------------------------------
for fp in [
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf",
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf",
]:
    try:
        font_manager.fontManager.addfont(fp)
    except Exception:
        pass

plt.rcParams["font.family"] = "Roboto"
plt.rcParams["font.sans-serif"] = ["Roboto"]

# --- Paths ----------------------------------------------------------------
# Input file: ratios (min/mean/max) to BO optimum for each indicator
input_path = r"D:\soft\python\LHS\figure11f_ratio_to_bo_optimum.xlsx"
# Output figure
output_path = r"D:\soft\python\LHS\figure11f_ratio_to_bo_optimum.png"

# --- Load data ------------------------------------------------------------
df = pd.read_excel(input_path, sheet_name=0)
df.set_index("Indicator", inplace=True)
# Keep only Min / Mean / Max and round for display
data = df[["Min", "Mean", "Max"]].round(3)

# --- Create figure --------------------------------------------------------
fig, ax = plt.subplots(figsize=(8, 5), facecolor="white")

# Heatmap: viridis_r (yellow = low values) + alpha = 0.6
heatmap = sns.heatmap(
    data,
    annot=True,
    fmt=".3f",
    cmap="viridis_r",              # reversed viridis: yellow = minimum
    alpha=0.6,                     # overall transparency 60%
    cbar_kws={"label": "Ratio to BO optimum"},
    linewidths=0.5,
    linecolor="black",
    ax=ax,
)

# --- Axes and labels ------------------------------------------------------
ax.set_xlabel("Ratio to BO optimum", fontsize=19)
ax.set_ylabel("Indicator", fontsize=19)
ax.tick_params(axis="x", labelsize=15)
ax.tick_params(axis="y", labelsize=15)

# Font size of numbers inside the cells
for t in ax.texts:
    t.set_fontsize(17)

# --- Colorbar settings ----------------------------------------------------
cbar = heatmap.collections[0].colorbar
cbar.ax.tick_params(labelsize=15)
cbar.set_label("Ratio to BO optimum", fontsize=19)

# --- Frame linewidth ------------------------------------------------------
for spine in ax.spines.values():
    spine.set_linewidth(1.5)

# --- Save figure ----------------------------------------------------------
plt.tight_layout()
plt.savefig(output_path, dpi=600, facecolor="white")
plt.close()

print(f"Saved Figure 11f to: {output_path}")
