# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.lines import Line2D
from matplotlib import font_manager

# --- 字体设置：Roboto --------------------------------------------------------
for fp in [
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf",
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf",
]:
    try:
        font_manager.fontManager.addfont(fp)
    except Exception:
        pass
rcParams['font.family'] = 'Roboto'
rcParams['font.sans-serif'] = ['Roboto']

# --- 文件路径 ---------------------------------------------------------------
input_path = r"D:\soft\python\LHS\ZONG.xlsx"
output_path = r"D:\soft\python\LHS\GWP_Scatter_Print_Speed_Raster_angle_Top5_Roboto.png"

# --- 读取数据 ---------------------------------------------------------------
df = pd.read_excel(input_path)

# 提取变量
x = df['Layer_Height']
y = df['Infill_Density']
z = df['GWP'] * 100  # ×10² 显示

# 去重后取 GWP 最小 6 个
subset_cols = ['Print_Speed', 'Layer_Height', 'Infill_Density', 'Raster Angle']
df_sorted = df.sort_values('GWP', ascending=True)
unique_rows = df_sorted.drop_duplicates(subset=subset_cols, keep='first')
top6 = unique_rows.head(6)
if len(top6) < 6:
    raise ValueError("去重后不足 6 个样本，请检查数据。")

idx1, idx2, idx3, idx4, idx5, idx6 = top6.index.tolist()

# --- 绘图 --------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8, 6), facecolor='white')

# 底图散点
scatter = ax.scatter(
    x, y, c=z, cmap='viridis_r',
    edgecolors='black', linewidths=0.5
)

# 叠加标记
ax.scatter(x.loc[idx1], y.loc[idx1], facecolors='none', edgecolors='black', linewidths=1.6, s=120)
ax.scatter(x.loc[idx2], y.loc[idx2], facecolors='none', edgecolors='red', linewidths=1.6, s=120)
for idx in [idx3, idx4, idx6]:
    ax.scatter(x.loc[idx], y.loc[idx], facecolors='none', edgecolors='blue', linewidths=1.6, s=120)

# 坐标轴
ax.set_xlabel("Layer Height (mm)", fontsize=19)
ax.set_ylabel("Infill Density (%)", fontsize=19)
ax.tick_params(axis='both', labelsize=15)

# 坐标范围
ax.set_xlim(0.05, 0.35)
ax.set_ylim(10, 100)

# 色条（7级）
levels = np.linspace(z.min(), z.max(), 7)
cbar = plt.colorbar(scatter, ax=ax, ticks=levels, format='%.3f')
cbar.set_label("Predicted GWP (kg CO₂ eq ×10⁻²)", fontsize=19)
cbar.ax.tick_params(labelsize=13)

# 图例（Roboto）
handles = [
    Line2D([0],[0], marker='o', linestyle='None',
           markersize=10, markerfacecolor='none',
           markeredgecolor='black', markeredgewidth=1.6,
           label='Optimal set'),
    Line2D([0],[0], marker='o', linestyle='None',
           markersize=10, markerfacecolor='none',
           markeredgecolor='red', markeredgewidth=1.6,
           label='Second-best set'),
    Line2D([0],[0], marker='o', linestyle='None',
           markersize=10, markerfacecolor='none',
           markeredgecolor='blue', markeredgewidth=1.6,
           label='Near-optimal set'),
]
ax.legend(handles=handles, loc='upper left', frameon=False,
          prop={'family': 'Roboto', 'size': 15})

# 网格与布局
ax.grid(False)
plt.tight_layout()
plt.savefig(output_path, dpi=600)
plt.close()

print(f"[SAVE] 图已保存至：{output_path}")
