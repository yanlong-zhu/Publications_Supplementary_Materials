import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib import font_manager
from sklearn.metrics import r2_score, mean_absolute_percentage_error

"""
Reproduce Figure 6: predicted vs actual plots for GWP, FRS, OFHH and TA
using EC/MC-based random forest models.

Input:
    figure6_pred_vs_actual_data.csv
        columns: Indicator, Real, Predicted

Output:
    GWP_Predicted_vs_Actual.png
    FRS_Predicted_vs_Actual.png
    OFHH_Predicted_vs_Actual.png
    TA_Predicted_vs_Actual.png
"""

# ==== Register fonts (use actual paths on your machine) ====
font_manager.fontManager.addfont(
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf"
)
font_manager.fontManager.addfont(
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf"
)
font_manager.fontManager.addfont(
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\RobotoMono-Regular.ttf"
)

plt.rcParams["font.family"] = "Roboto"
plt.rcParams["font.sans-serif"] = ["Roboto"]

# ==== Paths ====
csv_path = r"D:\soft\python\LHS\figure6_pred_vs_actual_data.csv"
out_dir = r"D:\soft\python\LHS"
os.makedirs(out_dir, exist_ok=True)

# ==== Read data ====
df = pd.read_csv(csv_path)


def norm(s: str) -> str:
    """Normalise indicator names (strip + lower-case)."""
    return str(s).strip().lower()


# Map various indicator names to canonical keys
alias_to_key = {
    # GWP
    norm("Global warming"): "GWP",
    # FRS
    norm("Fossil resource scarcity"): "FRS",
    # OFHH (support multiple spellings)
    norm("Ozone formation"): "OFHH",
    norm("Ozone formation, Human health"): "OFHH",
    # TA
    norm("Terrestrial acidification"): "TA",
}

# Add canonical key column (GWP / FRS / OFHH / TA)
df["Canonical"] = df["Indicator"].apply(lambda x: alias_to_key.get(norm(x), None))

# Desired output order
order = ["GWP", "FRS", "OFHH", "TA"]

# Units, scaling factors and scaling labels
units = {
    "GWP": "kg CO₂ eq",
    "FRS": "kg oil eq",
    "OFHH": "kg NOx eq",
    "TA": "kg SO₂ eq",
}

scale = {
    "GWP": 1e1,   # plot values × 10⁻¹
    "FRS": 1e2,   # plot values × 10⁻²
    "OFHH": 1e4,  # plot values × 10⁻⁴
    "TA": 1e4,    # plot values × 10⁻⁴
}

scale_str = {
    "GWP": "×10⁻¹",
    "FRS": "×10⁻²",
    "OFHH": "×10⁻⁴",
    "TA": "×10⁻⁴",
}

# Colors (blue / orange)
blue_rgb = (31 / 255, 119 / 255, 180 / 255)
orange_rgb = (254 / 255, 127 / 255, 15 / 255)


def plot_key(key: str):
    """Plot predicted vs actual for one indicator (key)."""
    sub = df[df["Canonical"] == key].copy()
    if sub.empty:
        print(f"Skip: no data for {key}")
        return None

    y_true = sub["Real"].values
    y_pred = sub["Predicted"].values

    r2 = r2_score(y_true, y_pred)
    mape = mean_absolute_percentage_error(y_true, y_pred) * 100

    fig, ax = plt.subplots(figsize=(6, 5.5), facecolor="white")

    # Scatter (predicted vs actual)
    ax.scatter(
        y_true,
        y_pred,
        color=blue_rgb,
        s=25,
        alpha=0.6,
        marker="x",
        label="Predicted",
    )

    # Ideal y = x line
    mn = min(y_true.min(), y_pred.min())
    mx = max(y_true.max(), y_pred.max())
    ax.plot(
        [mn, mx],
        [mn, mx],
        linestyle="--",
        color=orange_rgb,
        linewidth=1.5,
        label="Ideal fit",
    )

    # Axis units and scaling
    sf = scale[key]
    sstr = scale_str[key]
    unit = units[key]

    ax.xaxis.set_major_formatter(
        ticker.FuncFormatter(lambda x, _: f"{x * sf:.2f}")
    )
    ax.yaxis.set_major_formatter(
        ticker.FuncFormatter(lambda y, _: f"{y * sf:.2f}")
    )

    ax.set_xlabel(f"Actual ({sstr} {unit})", fontsize=19)
    ax.set_ylabel(f"Predicted ({sstr} {unit})", fontsize=19)

    ax.tick_params(axis="both", labelsize=15)
    for spine in ax.spines.values():
        spine.set_linewidth(1.5)

    # Title: indicator key + R² + MAPE
    ax.set_title(f"{key}  R²={r2:.3f}, MAPE={mape:.2f}%", fontsize=17)

    ax.legend(loc="upper left", fontsize=15, frameon=False)
    plt.tight_layout()

    out_png = os.path.join(out_dir, f"{key}_Predicted_vs_Actual.png")
    plt.savefig(out_png, dpi=600)
    plt.close()
    return out_png


# Batch export
paths = [p for k in order if (p := plot_key(k))]

print("Generated files:")
for p in paths:
    print(" -", p)
