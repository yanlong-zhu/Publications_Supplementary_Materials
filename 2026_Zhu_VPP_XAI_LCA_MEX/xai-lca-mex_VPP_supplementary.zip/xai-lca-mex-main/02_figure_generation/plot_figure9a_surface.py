# -*- coding: utf-8 -*-
"""
2D response surface (GWP | TOTAL = EC + MC)
Sparse-node model prediction + interval densification via sequential 1D interpolation.

- Data (used ONLY to lock the other parameters to their medians):
    D:\soft\python\LHS\434.xlsx
- Models:
    D:\soft\python\LHS\EC-RFM.pkl
    D:\soft\python\LHS\MC-RFM.pkl
- Plot:
    Filled contour of TOTAL GWP (EC + MC)
    x-axis = Print_Speed, y-axis = Layer_Height
- Styling:
    Roboto font only (everything else unchanged),
    viridis_r (yellow = low),
    fixed contour levels derived from the original range 0.008 → 0.092 (step 0.004),
    then scaled to the calibrated scale.
- IMPORTANT:
    Your data file has already been scaled (80W scale). The PKL models are not,
    so we rescale the MODEL OUTPUT here by SCALE_FACTOR.
    Also, we display GWP in ×10^-1 on the colorbar.
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.ticker as ticker
from matplotlib import font_manager
from joblib import load as joblib_load


# ====================== CONFIG ======================
BASE_DIR = r"D:\soft\python\LHS"
DATA_PATH = os.path.join(BASE_DIR, "434.xlsx")
EC_MODEL_PATH = os.path.join(BASE_DIR, "EC-RFM.pkl")
MC_MODEL_PATH = os.path.join(BASE_DIR, "MC-RFM.pkl")

# Axes (x = speed, y = layer height)
X_NAME = "Print_Speed"
Y_NAME = "Layer_Height"
X_LABEL = "Print Speed (mm/s)"
Y_LABEL = "Layer Height (mm)"

# Sparse node grid (where we actually call the models)
X_NODES = np.array([20, 40, 60, 80, 100, 120, 140], dtype=float)
Y_NODES = np.array([0.08, 0.12, 0.16, 0.20, 0.24, 0.28, 0.32], dtype=float)

# Points inserted per interval (e.g., 20↔40 insert 19 points -> 20,21,...,40)
X_INSERTS = 19
Y_INSERTS = 19

# Feature columns (must match training / model expectation)
FEATURE_ORDER = [
    "Print_Speed",
    "Layer_Height",
    "Infill_Density",
    "Grating angle",  # if the data has Raster_Angle etc, we rename them to this
]

# Multi-output index for GWP (if model outputs shape (n,4), take column 0)
GWP_INDEX = 0

# ===== MODEL OUTPUT RESCALING (old scale -> calibrated scale) =====
# If your PKLs still output the old scale, keep this as 80/27.
# If your PKLs are already calibrated, set to 1.0.
SCALE_FACTOR = 80.0 / 27.0

# ===== Fixed contour range (original) and scaled range =====
# Original (old-scale) fixed range used previously:
GWP_MIN0, GWP_MAX0, GWP_STEP0 = 0.008, 0.092, 0.004

# Apply the same factor to keep the visual design consistent under rescaling:
GWP_MIN = GWP_MIN0 * SCALE_FACTOR
GWP_MAX = GWP_MAX0 * SCALE_FACTOR
GWP_STEP = GWP_STEP0 * SCALE_FACTOR

LEVELS = np.arange(GWP_MIN, GWP_MAX + GWP_STEP * 0.125, GWP_STEP)
TICKS = np.linspace(GWP_MIN, GWP_MAX, 7)

# Output
OUT_DIR = os.path.join(BASE_DIR, "fig_out")
os.makedirs(OUT_DIR, exist_ok=True)
OUTFILE = os.path.join(OUT_DIR, f"GWP_TOTAL_sparse_interp_{X_NAME}_vs_{Y_NAME}.png")

# Font (Roboto only; otherwise do not change style)
font_paths = [
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf",
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf",
]
for fp in font_paths:
    if os.path.exists(fp):
        font_manager.fontManager.addfont(fp)

mpl.rcParams["font.family"] = "Roboto"
mpl.rcParams["font.sans-serif"] = ["Roboto"]

# Colormap: reversed viridis (yellow = low)
CMAP = mpl.colormaps.get_cmap("viridis_r")
# =====================================================


def safe_load_model(path: str):
    """Load a model via joblib; fallback to pickle if needed."""
    try:
        return joblib_load(path)
    except Exception:
        import pickle
        with open(path, "rb") as f:
            return pickle.load(f)


def predict_gwp(model, Xdf: pd.DataFrame) -> np.ndarray:
    """
    Predict and return GWP as a 1D array (n,).
    If model output is (n,k), take GWP_INDEX column.
    """
    X = Xdf[FEATURE_ORDER]
    if hasattr(model, "predict"):
        y = model.predict(X)
    elif callable(model):
        y = model(X)
    else:
        raise TypeError("Model has neither .predict nor is it callable.")

    y = np.asarray(y)
    if y.ndim == 2:
        if not (0 <= GWP_INDEX < y.shape[1]):
            raise IndexError(f"GWP_INDEX={GWP_INDEX} out of bounds for output dim {y.shape[1]}.")
        y = y[:, GWP_INDEX]
    return y.ravel()


def expand_equal_division(nodes: np.ndarray, inserts: int) -> np.ndarray:
    """
    Given sorted nodes, insert 'inserts' equally spaced points in each interval.
    Example: nodes=[20,40], inserts=19 -> [20,21,...,40]
    """
    nodes = np.unique(nodes.astype(float))
    parts = []
    for i in range(len(nodes) - 1):
        a, b = nodes[i], nodes[i + 1]
        seg = np.linspace(a, b, inserts + 2, endpoint=False)  # include left, exclude right
        parts.append(seg)
    parts.append(np.array([nodes[-1]]))
    return np.concatenate(parts)


def interp2_sequential_1d(
    X_nodes: np.ndarray,
    Y_nodes: np.ndarray,
    Z_nodes: np.ndarray,
    X_dense: np.ndarray,
    Y_dense: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Build a dense surface by sequential 1D interpolation:
    1) interpolate along X for each Y row
    2) interpolate along Y for each X column
    Uses cubic if enough points, otherwise linear.
    """
    from scipy.interpolate import interp1d

    kind_x = "cubic" if len(X_nodes) >= 4 else "linear"
    kind_y = "cubic" if len(Y_nodes) >= 4 else "linear"

    # Along X for each Y row
    Zx = np.zeros((len(Y_nodes), len(X_dense)))
    for i in range(len(Y_nodes)):
        f = interp1d(X_nodes, Z_nodes[i, :], kind=kind_x, bounds_error=False, fill_value="extrapolate")
        Zx[i, :] = f(X_dense)

    # Along Y for each X column
    Zf = np.zeros((len(Y_dense), len(X_dense)))
    for j in range(len(X_dense)):
        f = interp1d(Y_nodes, Zx[:, j], kind=kind_y, bounds_error=False, fill_value="extrapolate")
        Zf[:, j] = f(Y_dense)

    XX, YY = np.meshgrid(X_dense, Y_dense)
    return XX, YY, Zf

def main():
    # 1) Read data (ONLY for medians of the other parameters) and normalize angle column names
    df = pd.read_excel(DATA_PATH).rename(columns={
        "Raster_Angle": "Grating angle",
        "Raster angle": "Grating angle",
        "RasterAngle": "Grating angle",
        "Grating_angle": "Grating angle",  # match the column name in 434.xlsx
    })

    med = df.median(numeric_only=True)

    # Ensure the locked features exist (except X/Y which we overwrite)
    required_locked = [c for c in FEATURE_ORDER if c not in (X_NAME, Y_NAME)]
    missing_locked = [c for c in required_locked if c not in med.index]
    if missing_locked:
        raise ValueError(
            f"Missing columns in {os.path.basename(DATA_PATH)} needed to lock medians: {missing_locked}\n"
            f"Available columns: {list(df.columns)}"
        )

    # 2) Sparse node grid
    X_nodes = np.unique(X_NODES.astype(float))
    Y_nodes = np.unique(Y_NODES.astype(float))
    XX_nodes, YY_nodes = np.meshgrid(X_nodes, Y_nodes)

    # 3) Build feature table: lock other parameters to their medians
    n_sparse = XX_nodes.size
    feat = pd.DataFrame({col: np.full(n_sparse, med.get(col, np.nan)) for col in FEATURE_ORDER})
    feat[X_NAME] = XX_nodes.ravel()
    feat[Y_NAME] = YY_nodes.ravel()

    # 4) Load models and predict TOTAL = EC + MC at sparse nodes
    ec = safe_load_model(EC_MODEL_PATH)
    mc = safe_load_model(MC_MODEL_PATH)

    y_ec = predict_gwp(ec, feat)
    y_mc = predict_gwp(mc, feat)

    # Rescale MODEL OUTPUT here (because your dataset is already scaled, but PKLs are not)
    Z_nodes = ((y_ec + y_mc) * SCALE_FACTOR).reshape(YY_nodes.shape)  # (len(Y_nodes), len(X_nodes))

    # 5) Densify axes by equal division
    X_dense = expand_equal_division(X_nodes, X_INSERTS)
    Y_dense = expand_equal_division(Y_nodes, Y_INSERTS)

    # 6) Build dense surface via sequential 1D interpolation
    XX, YY, Zf = interp2_sequential_1d(X_nodes, Y_nodes, Z_nodes, X_dense, Y_dense)

    # 7) Plot with fixed levels and viridis_r
    fig, ax = plt.subplots(figsize=(8, 6))
    contour = ax.contourf(XX, YY, Zf, levels=LEVELS, cmap=CMAP, extend="both")

    ax.set_xlabel(X_LABEL, fontsize=19)
    ax.set_ylabel(Y_LABEL, fontsize=19)
    ax.tick_params(axis="both", labelsize=15)

    # Colorbar: show GWP as ×10^-1 (i.e., display value = actual * 10)
    cbar = fig.colorbar(contour, ax=ax, ticks=TICKS)
    cbar.ax.yaxis.set_major_formatter(
        ticker.FuncFormatter(lambda v, _: f"{v * 10:.2f}")
    )
    cbar.ax.set_ylabel("Predicted GWP (×10⁻¹ kg CO$_2$ eq)", fontsize=19)
    cbar.ax.tick_params(labelsize=15)

    plt.tight_layout()
    plt.savefig(OUTFILE, dpi=600)
    plt.close()
    print(f"[SAVE] {OUTFILE}")


if __name__ == "__main__":
    main()
