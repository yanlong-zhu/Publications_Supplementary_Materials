Geometries (STL files)
This folder contains the STL geometries used in this repository.

Units: millimetres (mm)
Intended use: material-extrusion (MEX/FDM) printing
Coordinate system: standard right-handed convention (as exported in STL)

Files
- rect_specimen_180x15x2p4mm.stl
  Rectangular tensile specimen used to generate the main dataset and the primary results reported in the paper.

- 3DBenchy_calibration_boat.stl
  3DBenchy benchmark geometry used as an illustrative case in the Discussion to demonstrate that the same slicer → EC/MC → LCA workflow transfers to a realistic 3D part.

Note
3DBenchy is a third-party benchmark model released under the CC0 1.0 Universal (Public Domain Dedication) license.
Source: downloaded from the official 3DBenchy website (https://www.3dbenchy.com/) or its linked mirrors (e.g., MyMiniFactory).
